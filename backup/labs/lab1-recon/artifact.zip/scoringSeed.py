import hashlib, secrets

students = ["uma"]  # replace with real IDs

for s in students:
    seed = secrets.token_hex(8)
    print(f"Student: {s:15} | STUDENT_ID={s} LAB_SEED={seed}")